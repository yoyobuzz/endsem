function f = kur_MO(x)

D = length(x);

f(1) = sum(-10*exp(-0.2*sqrt(x(1:D-1).^2 + x(2:D).^2)));
f(2) = sum(abs(x(1:D)).^0.8 + 5*sin(x(1:D).^3));