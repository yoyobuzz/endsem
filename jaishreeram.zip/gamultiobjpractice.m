clc;clear

ub = [5 5 5];
lb = -ub;

nvars = length(lb);
fitnessfcn = @kur_MO;
[x1,fval1,exitflag,output,population,scores] = gamultiobj(fitnessfcn,nvars,[],[],[],[],lb,ub);
plot(fval1(:,1),fval1(:,2),'r*')
xlabel('Minimize f_1')
ylabel('Minimize f_2')