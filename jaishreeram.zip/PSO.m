function [bestsol,bestfitness,bestfiter,P,f]=PSO(prob,lb,ub,Np,c1,c2,w,T)

f=NaN(Np,1);
bestfiter=NaN(T+1,1);

D=length(lb);

P=repmat(lb,Np,1)+repmat((ub-lb),Np,1).*rand(Np,D);
V=repmat(lb,Np,1)+repmat((ub-lb),Np,1).*rand(Np,D);

for i= 1: Np
    f(i)=prob(P(i,:));
end
bestfiter(1)=min(f);
pbest =P;
fbest =f;

[fgbest,idx]=min(fbest);
gbest=P(idx,:);

for j= 1:T
    for i= 1:Np
        
        V(i,:)=w*v(i,:)+c1*rand(1,D)*(pbest(i,:)-P(i,:))+c2*rand(1,D)*(gbest-P(i,:));
        P(i,:)=P(i,:)+V(i,:);
        
        P(i,:)=min(P(i,:),lb);
        P(i,:)=max(P(i,:),ub);

        f(i)=prob(P(i,:));

        if(f(i)<fbest)
            fbest=f(i);
            pbest(i,:)=P(i,:);
        end
        if(f(i)<fgbest)
            fgbest=f(i);
            gbest=P(i,:);
        end
    end
    bestfiter(j+1)=fgbest;
end

bestfitness=fgbest;
bestsol=gbest;